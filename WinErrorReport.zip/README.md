# Windows Error Report Tool 2.5 Final

Diagnose-Tool zum übersichtlichen Auslesen und Filtern der Windows-Ereignisanzeige (System-, Anwendungs- und Sicherheitsprotokoll) für Windows 7, 10 und 11 – ohne Installation, direkt per PowerShell-Skript.

## Funktionen
- 9 Kategorien: Kritische Fehler, Schwere Fehler, Anwendungsfehler, Kernel-Abstürze, Datenträgerfehler, Netzwerkfehler, Windows-Update-Fehler, Treiber-/Hardware-Fehler, Sicherheitsprotokoll
- Remote-Abfrage anderer Computer (mit optionalen Anmeldedaten)
- Suche, Mehrfachauswahl, eigene Notizen zu bekannten Fehlern
- Export als CSV, TXT oder HTML-Report
- Rechtsklick-Menü: Meldung kopieren, in Ereignisanzeige öffnen, mit Google suchen, ausführlichen Fehlerbericht (WER) öffnen
- Zweisprachig (Deutsch/Englisch) mit automatischer Spracherkennung
- Kompatibel von Windows 7 (PowerShell 2.0) bis Windows 11

## Voraussetzungen
- Windows 7, 10 oder 11
- PowerShell (in Windows bereits enthalten)
- Für das Sicherheitsprotokoll: Administratorrechte (werden bei Bedarf abgefragt)


## Haftungsausschluss
Dieses Tool liest ausschließlich vorhandene Windows-Ereignisprotokolle aus und verändert keine Systemdateien. Die Nutzung erfolgt dennoch vollständig **auf eigene Gefahr**. Für Datenverluste, Systemschäden oder sonstige direkte oder indirekte Schäden im Zusammenhang mit der Nutzung dieses Tools wird **keinerlei Haftung** übernommen.

## Autor
© Copyright Björn Scherf 2026

Ich freue mich über eine Spende – Infos dazu unter www.alpha10.de

---

# Windows Error Report Tool 2.5 Final

Diagnostic tool for reading and filtering the Windows Event Log (System, Application, and Security logs) in a clear overview, for Windows 7, 10, and 11 – no installation required, runs directly as a PowerShell script.

## Features
- 9 categories: Critical Errors, Serious Errors, Application Errors, Kernel Crashes, Disk Errors, Network Errors, Windows Update Errors, Driver/Hardware Errors, Security Log
- Remote query of other computers (with optional credentials)
- Search, multi-select, custom notes for known errors
- Export as CSV, TXT, or HTML report
- Right-click menu: copy message, open in Event Viewer, search with Google, open detailed error report (WER)
- Bilingual (German/English) with automatic language detection
- Compatible from Windows 7 (PowerShell 2.0) to Windows 11

## Requirements
- Windows 7, 10, or 11
- PowerShell (included in Windows)
- Administrator rights required for the Security Log (requested automatically when needed)


## Disclaimer
This tool only reads existing Windows event logs and does not modify any system files. Nevertheless, use is entirely **at your own risk**. **No liability whatsoever** is assumed for data loss, system damage, or any other direct or indirect damages arising from the use of this tool.

## Author
© Copyright Björn Scherf 2026

I would appreciate a donation – details at www.alpha10.de
